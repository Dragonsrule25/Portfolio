const form = document.getElementById('study-form');
const subjectInput = document.getElementById('subject');
const durationInput = document.getElementById('duration');
const studyList = document.getElementById('study-list');
const totalTimeDisplay = document.getElementById('total-time');

let totalMinutes = 0;

form.addEventListener('submit', function (e) {
  e.preventDefault();

  const subject = subjectInput.value.trim();
  const duration = parseInt(durationInput.value);

  if (!subject || isNaN(duration) || duration < 1) {
    alert('Please enter a valid subject and duration.');
    return;
  }

  const listItem = document.createElement('li');
  listItem.textContent = `${subject} - ${duration} minutes`;
  studyList.appendChild(listItem);

  totalMinutes += duration;
  totalTimeDisplay.textContent = `Total Time Studied: ${totalMinutes} minutes`;

  subjectInput.value = '';
  durationInput.value = '';
});
