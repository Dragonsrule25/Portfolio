document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Thanks for reaching out! I’ll get back to you soon. 🐾");
  this.reset();
});

document.addEventListener("DOMContentLoaded", function () {
  const year = new Date().getFullYear();
  const footer = document.querySelector("footer p");
  if (footer) {
    footer.innerHTML = `© ${year} Pet Sitting by Olivia | All rights reserved`;
  }
});

document.querySelectorAll(".gallery-grid img").forEach((img) => {
  img.style.cursor = "pointer";
  img.addEventListener("click", () => {
    const overlay = document.createElement("div");
    overlay.style.position = "fixed";
    overlay.style.top = 0;
    overlay.style.left = 0;
    overlay.style.width = "100vw";
    overlay.style.height = "100vh";
    overlay.style.background = "rgba(0, 0, 0, 0.8)";
    overlay.style.display = "flex";
    overlay.style.alignItems = "center";
    overlay.style.justifyContent = "center";
    overlay.style.zIndex = 1000;

    const fullImg = document.createElement("img");
    fullImg.src = img.src;
    fullImg.style.maxWidth = "90%";
    fullImg.style.maxHeight = "90%";
    fullImg.style.borderRadius = "12px";
    fullImg.style.boxShadow = "0 0 30px rgba(0, 0, 0, 0.5)";
    overlay.appendChild(fullImg);

    overlay.addEventListener("click", () => document.body.removeChild(overlay));
    document.body.appendChild(overlay);
  });
});

document.addEventListener("mousemove", function (e) {
  const paw = document.createElement("span");
  paw.textContent = "🐾";
  paw.style.position = "absolute";
  paw.style.left = `${e.pageX}px`;
  paw.style.top = `${e.pageY}px`;
  paw.style.pointerEvents = "none";
  paw.style.opacity = 0.8;
  paw.style.fontSize = "20px";
  paw.style.zIndex = 999;
  document.body.appendChild(paw);

  setTimeout(() => {
    paw.remove();
  }, 500);
});
document.addEventListener('DOMContentLoaded', () => {
  const questions = document.querySelectorAll('#faq dt');

  questions.forEach((dt) => {
    dt.addEventListener('click', () => {
      const answer = dt.nextElementSibling;
      if (!answer) return;

      const isOpen = answer.classList.contains('show');

      if (isOpen) {
       
        answer.classList.remove('show');
        dt.classList.remove('active');

        setTimeout(() => {
          answer.classList.add('hidden');
        }, 350); 
      } else {
    
        answer.classList.remove('hidden');
        requestAnimationFrame(() => {
          answer.classList.add('show');
        });
        dt.classList.add('active');
      }
    });
  });
});

